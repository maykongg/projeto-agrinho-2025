let player;

let items = [];

let score = 0;

let phase = 1;

let collected = 0;

let totalFruits = 3;

let gameState = "select"; // select, start, playing, gameover

let selectedColor = "yellow";

let availableColors = ["yellow", "blue", "green", "red"];

let timer = 30;

let lives = 3;

let lastSecond;

function preload() {

  collectSound = { play: () => console.log("Coletou fruta") };

  damageSound = { play: () => console.log("Tomou dano") };

}

function setup() {

  createCanvas(800, 400);

  textAlign(CENTER);

  player = new Player();

  lastSecond = millis();

}

function draw() {

  background(120, 200, 100);

  if (gameState === "select") showCharacterSelection();

  else if (gameState === "start") showStartScreen();

  else if (gameState === "playing") runGame();

  else if (gameState === "gameover") showGameOver();

}

function showCharacterSelection() {

  background(50, 100, 200);

  fill(255);

  textSize(30);

  text("Escolha a cor do seu personagem", width / 2, 40);

  for (let i = 0; i < availableColors.length; i++) {

    fill(availableColors[i]);

    ellipse(150 + i * 150, height / 2, 60);

  }

  fill(255);

  textSize(20);

  text("Clique em uma cor para começar", width / 2, height - 40);

}

function showStartScreen() {

  background(50, 150, 200);

  fill(255);

  textSize(30);

  text("🌱 Jogo do Agrinho!", width / 2, height / 2 - 20);

  textSize(20);

  text("Pressione ENTER para começar", width / 2, height / 2 + 20);

}

function runGame() {

  player.move();

  player.display();

  for (let item of items) {

    item.display();

    if (!item.collected && item.checkCollision(player)) {

      item.collected = true;

      if (item.type === "fruit") {

        score += 10;

        collected++;

        collectSound.play();

      } else if (item.type === "trash") {

        lives--;

        damageSound.play();

        if (lives <= 0) {

          gameState = "gameover";

        }

      }

    }

  }

  fill(0);

  textSize(20);

  textAlign(LEFT);

  text(`Fase: ${phase}`, 10, 20);

  text(`Pontuação: ${score}`, 10, 45);

  text(`Vidas: ${lives}`, 10, 70);

  text(`Tempo: ${timer}`, 10, 95);

  if (millis() - lastSecond >= 1000) {

    timer--;

    lastSecond = millis();

    if (timer <= 0) {

      gameState = "gameover";

    }

  }

  if (collected === totalFruits) {

    nextPhase();

  }

}

function showGameOver() {

  background(0);

  fill(255);

  textSize(40);

  text("💀 FIM DE JOGO 💀", width / 2, height / 2 - 20);

  textSize(20);

  text("Pressione ENTER para recomeçar", width / 2, height / 2 + 30);

}

function keyPressed() {

  if (gameState === "start" && keyCode === ENTER) {

    gameState = "playing";

    generateItems();

    timer = 30;

    lives = 3;

  } else if (gameState === "gameover" && keyCode === ENTER) {

    resetGame();

  }

}

function mousePressed() {

  if (gameState === "select") {

    for (let i = 0; i < availableColors.length; i++) {

      let x = 150 + i * 150;

      if (dist(mouseX, mouseY, x, height / 2) < 30) {

        selectedColor = availableColors[i];

        player.color = selectedColor;

        gameState = "start";

      }

    }

  }

}

function resetGame() {

  phase = 1;

  score = 0;

  collected = 0;

  totalFruits = 3;

  lives = 3;

  timer = 30;

  gameState = "start";

}

function nextPhase() {

  phase++;

  collected = 0;

  totalFruits += 2;

  timer = 30;

  generateItems();

}

function generateItems() {

  items = [];

  let positions = [];

  function isFarEnough(x, y) {

    for (let pos of positions) {

      if (dist(x, y, pos.x, pos.y) < 50) return false;

    }

    return true;

  }

  let tries = 0;

  while (items.filter(i => i.type === "fruit").length < totalFruits && tries < 1000) {

    let x = random(100, 700);

    let y = random(50, 350);

    if (isFarEnough(x, y)) {

      let type = random(["apple", "banana", "grape"]);

      items.push(new Item(x, y, "fruit", type));

      positions.push({ x, y });

    }

    tries++;

  }

  while (items.filter(i => i.type === "trash").length < phase + 2 && tries < 2000) {

    let x = random(100, 700);

    let y = random(50, 350);

    if (isFarEnough(x, y)) {

      items.push(new Item(x, y, "trash"));

      positions.push({ x, y });

    }

    tries++;

  }

}

class Player {

  constructor() {

    this.x = 50;

    this.y = height / 2;

    this.size = 40;

    this.speed = 5;

    this.color = selectedColor;

  }

  move() {

    if (keyIsDown(LEFT_ARROW)) this.x -= this.speed;

    if (keyIsDown(RIGHT_ARROW)) this.x += this.speed;

    if (keyIsDown(UP_ARROW)) this.y -= this.speed;

    if (keyIsDown(DOWN_ARROW)) this.y += this.speed;

    this.x = constrain(this.x, 0, width);

    this.y = constrain(this.y, 0, height);

  }

  display() {

    fill(this.color);

    ellipse(this.x, this.y, this.size);

  }

}

class Item {

  constructor(x, y, type, fruitType = "apple") {

    this.x = x;

    this.y = y;

    this.size = 30;

    this.type = type;

    this.fruitType = fruitType;

    this.collected = false;

  }

  display() {

    if (!this.collected) {

      if (this.type === "fruit") {

        if (this.fruitType === "apple") fill(255, 0, 0);

        else if (this.fruitType === "banana") fill(255, 255, 0);

        else if (this.fruitType === "grape") fill(160, 0, 255);

        ellipse(this.x, this.y, this.size);

      } else {

        fill(80);

        rect(this.x, this.y, this.size, this.size);

      }

    }

  }

  checkCollision(player) {

    return dist(this.x, this.y, player.x, player.y) < (this.size + player.size) / 2;

  }

}